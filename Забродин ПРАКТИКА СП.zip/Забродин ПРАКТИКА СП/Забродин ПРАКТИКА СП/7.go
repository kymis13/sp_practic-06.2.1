package main

import (
	"fmt"
)
type Employee struct {
	ID       int
	Name     string
	Position string
	Salary   float64
}
func calculateSalaryStats(employees []Employee) (float64, float64) {
	totalSalary := 0.0
	count := len(employees)

	if count == 0 {
		return 0.0, 0.0
	}
	for _, emp := range employees {
		totalSalary += emp.Salary
	}
	averageSalary := totalSalary / float64(count)

	return totalSalary, averageSalary
}

func main() {
	employees := []Employee{
		{ID: 1, Name: "Иван Иванов", Position: "Разработчик", Salary: 120000.50},
		{ID: 2, Name: "Анна Петрова", Position: "Тестировщик", Salary: 95000.00},
		{ID: 3, Name: "Сергей Сидоров", Position: "Тимлид", Salary: 210000.00},
		{ID: 4, Name: "Мария Кузнецова", Position: "HR-менеджер", Salary: 80000.25},
	}
	total, average := calculateSalaryStats(employees)
	fmt.Printf("Общий фонд оплаты труда (ФОТ): %.2f руб.\n", total)
	fmt.Printf("Средняя заработная плата:      %.2f руб.\n", average)
}
