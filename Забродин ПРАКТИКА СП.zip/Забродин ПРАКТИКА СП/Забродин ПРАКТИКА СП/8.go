package main

import (
	"fmt"
	"time"
)
type LogEntry struct {
	IP        string    
	HTTPCode  int       
	Timestamp time.Time 
}
func filterErrors(logs []LogEntry) []LogEntry {
	var errorLogs []LogEntry

	for _, entry := range logs {
		if entry.HTTPCode >= 400 && entry.HTTPCode <= 599 {
			errorLogs = append(errorLogs, entry)
		}
	}

	return errorLogs
}
func main() {
	logs := []LogEntry{
		{IP: "192.168.1.1", HTTPCode: 200, Timestamp: time.Now().Add(-10 * time.Minute)},
		{IP: "10.0.0.5", HTTPCode: 404, Timestamp: time.Now().Add(-8 * time.Minute)}, 
		{IP: "172.16.0.2", HTTPCode: 301, Timestamp: time.Now().Add(-5 * time.Minute)},
		{IP: "192.168.1.50", HTTPCode: 500, Timestamp: time.Now().Add(-2 * time.Minute)}, 
		{IP: "8.8.8.8", HTTPCode: 403, Timestamp: time.Now()},                            
	}
	badLogs := filterErrors(logs)
	fmt.Printf("Всего записей: %d. Найдено ошибок: %d\n\n", len(logs), len(badLogs))
	fmt.Println("Подозрительные запросы:")
	for _, entry := range badLogs {
		fmt.Printf("[%s] IP: %-13s -> Код: %d\n", 
			entry.Timestamp.Format("15:04:05"), entry.IP, entry.HTTPCode)
	}
}
