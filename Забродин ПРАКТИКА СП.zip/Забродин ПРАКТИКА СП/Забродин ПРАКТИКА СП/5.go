package main

import (
	"errors"
	"fmt"
	"strings"
)
func validateUser(name string, age int, email string) error {
	if name == "" {
		return errors.New("имя не должно быть пустым")
	}
	if len(name) >= 50 {
		return errors.New("длина имени должна быть меньше 50 символов")
	}
	if age < 18 || age > 120 {
		return errors.New("возраст должен быть в диапазоне от 18 до 120")
	}
	if strings.Index(email, "@") == -1 {
		return errors.New("email должен содержать символ '@'")
	}
	return nil
}
func main() {
	err := validateUser("Иван", 25, "ivan@example.com")
	if err != nil {
		fmt.Println("Ошибка валидации:", err)
	} else {
		fmt.Println("Пользователь успешно валидирован!")
	}
	err2 := validateUser("", 17, "invalid_email.com")
	if err2 != nil {
		fmt.Println("Ошибка валидации:", err2)
	}
}
