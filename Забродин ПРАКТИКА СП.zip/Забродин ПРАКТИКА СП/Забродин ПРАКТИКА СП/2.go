package main

import "fmt"

func main() {
	var bag, hand, dophand float64

	// Запрашиваем вес каждого элемента
	fmt.Print("Введите вес основного багажа: ")
	fmt.Scan(&bag)

	fmt.Print("Введите вес ручной клади: ")
	fmt.Scan(&hand)

	fmt.Print("Введите вес доп. ручной клади: ")
	fmt.Scan(&dophand)

	totalWeight := bag + hand + dophand
	fmt.Printf("Общий вес багажа: %.2f кг\n", totalWeight)
}
