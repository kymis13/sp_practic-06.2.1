package main

import "fmt"

func main() {
	weekday := 2100
	weekend := 2850

	total := weekday + // ВТ
		weekday +      // СР
		weekday +      // ЧТ
		weekend +      // ПТ
		weekend +      // СБ
		weekend +      // ВС
		weekday +      // ЧТ
		weekend        // ПТ

	
	fmt.Println(total)
}
