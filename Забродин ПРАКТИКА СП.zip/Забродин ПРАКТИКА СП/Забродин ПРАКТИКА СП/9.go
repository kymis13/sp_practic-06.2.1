package main

import (
	"errors"
	"fmt"
)
const (
	RoomSingle = "single"
	RoomDouble = "double"
	RoomSuite  = "suite"

	StatusFree        = "free"
	StatusBooked      = "booked"
	StatusMaintenance = "maintenance"
)
type HotelRoom struct {
	Type  string  
	Status string 
	Price  float64 
}
func bookRoom(rooms map[string]HotelRoom, roomNumber string) error {
	room, exists := rooms[roomNumber]
	if !exists {
		return fmt.Errorf("комната %s не существует", roomNumber)
	}
	switch room.Status {
	case StatusBooked:
		return fmt.Errorf("комната %s уже забронирована", roomNumber)
	case StatusMaintenance:
		return fmt.Errorf("комната %s находится на обслуживании", roomNumber)
	}
	room.Status = StatusBooked
	rooms[roomNumber] = room

	return nil
}
func main() {
	hotel := map[string]HotelRoom{
		"101": {Type: RoomSingle, Status: StatusFree, Price: 3000.0},
		"102": {Type: RoomDouble, Status: StatusBooked, Price: 5000.0},
		"201": {Type: RoomSuite, Status: StatusFree, Price: 12000.0},
		"202": {Type: RoomDouble, Status: StatusMaintenance, Price: 4500.0},
	}

	fmt.Println("--- Попытка бронирования свободной комнаты 101 ---")
	if err := bookRoom(hotel, "101"); err != nil {
		fmt.Println("Ошибка:", err)
	} else {
		fmt.Println("Успешно! Новый статус комнаты 101:", hotel["101"].Status)
	}

	fmt.Println("\n--- Попытка бронирования уже занятой комнаты 102 ---")
	if err := bookRoom(hotel, "102"); err != nil {
		fmt.Println("Ошибка:", err)
	}

	fmt.Println("\n--- Попытка бронирования комнаты на ремонте 202 ---")
	if err := bookRoom(hotel, "202"); err != nil {
		fmt.Println("Ошибка:", err)
	}
}
