package main

import (
	"fmt"
)
func countVotes(votes []string) {
	totalVotes := len(votes)
	if totalVotes == 0 {
		fmt.Println("Голоса отсутствуют.")
		return
	}
	candidates := []string{"Анна", "Борис", "Виктор"}
	voteCounts := make(map[string]int)
	for _, name := range candidates {
		voteCounts[name] = 0
	}
	for _, vote := range votes {
		if _, exists := voteCounts[vote]; exists {
			voteCounts[vote]++
		}
	}
	fmt.Printf("Всего проголосовало: %d\n\n", totalVotes)
	for _, name := range candidates {
		count := voteCounts[name]
		percentage := (float64(count) / float64(totalVotes)) * 100
		fmt.Printf("Кандидат %-6s: %d гол. (%.2f%%)\n", name, count, percentage)
	}
}
func main() {
	incomingVotes := []string{
		"Анна", "Борис", "Анна", "Виктор", "Борис", 
		"Анна", "Анна", "Виктор", "Борис", "Анна",
	}
	countVotes(incomingVotes)
}
