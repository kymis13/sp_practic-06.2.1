package main

import "fmt"

type Order struct {
	id          int       
	items       []int    
	total       float64   
	address     string    
	isCompleted bool     
}
var ordersMap = make(map[int]Order)
func addOrder(newOrder Order) {
	ordersMap[newOrder.id] = newOrder
}
func main() {
	order1 := Order
	{
		id:          101,
		items:       []int{5, 12, 43},
		total:       1450.50,
		address:     "ул. Ленина, д. 10",
		isCompleted: false,
	}
	addOrder(order1)
	fmt.Println("Список заказов в системе: ", ordersMap)
}
